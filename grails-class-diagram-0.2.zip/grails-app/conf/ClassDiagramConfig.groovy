/**
 * Default properties
 */
graphviz {
	dot.executable = "dot" // May include file path
}

classDiagram {
	defaultNode = [shape:"record", style:"rounded,solid,filled", color:"blue", fillcolor:"azure2"]
}